# TANUJA.exe

1. Open this folder in VS Code.
2. Install the "Live Server" extension, right-click index.html > Open with Live Server.
3. Edit the `C` object at the top of script.js (email, phone, linkedin, location, resume).

Files: index.html, styles.css, script.js, assets/
Routes: #/ (Home) and #/projects (Innovation Lab).
