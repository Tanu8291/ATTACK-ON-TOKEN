Put your resume here, e.g. assets/Tanuja_Adhav_Resume.pdf, then set resume:"assets/Tanuja_Adhav_Resume.pdf" in script.js (object C).
